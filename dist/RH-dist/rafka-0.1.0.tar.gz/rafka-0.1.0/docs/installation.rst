.. highlight:: shell

============
Installation
============

At the command line::

    $ easy_install rafka

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv rafka
    $ pip install rafka
