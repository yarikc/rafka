=====
Usage
=====

To use rafka in a project::

    import rafka
