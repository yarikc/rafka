#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_rafka
----------------------------------

Tests for `rafka` module.
"""

import unittest

from rafka import rafka


class TestRafka(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_000_something(self):
        pass


if __name__ == '__main__':
    import sys
    sys.exit(unittest.main())
