# -*- coding: utf-8 -*-

__author__ = 'thanos vassilakis'
__email__ = 'thanosv@gmail.com'
__version__ = '0.1.0'
