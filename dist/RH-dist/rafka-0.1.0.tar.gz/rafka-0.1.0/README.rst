===============================
rafka
===============================

.. image:: https://img.shields.io/pypi/v/rafka.svg
        :target: https://pypi.python.org/pypi/rafka

.. image:: https://img.shields.io/travis/thanos/rafka.svg
        :target: https://travis-ci.org/thanos/rafka

.. image:: https://readthedocs.org/projects/rafka/badge/?version=latest
        :target: https://readthedocs.org/projects/rafka/?badge=latest
        :alt: Documentation Status


A very simple REST interface to Kafka writen in Python based on the super fast Falcon.

* Free software: ISC license
* Documentation: https://rafka.readthedocs.org.

Features
--------

* TODO

Credits
---------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
